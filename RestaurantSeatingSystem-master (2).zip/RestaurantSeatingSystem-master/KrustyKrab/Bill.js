  
var value = prompt("Enter the mealcost", "0");
var mealCost = parseInt(value);
function Bill(){
	this.totalBill;
	this.tax;
	this.tip;


    /**
       Calculate 
    */
	this.calcTotalBill=function(){
            var tip=calcTip();
            var subTotal=calcSubTotal();
           this.totalBill= tip+subTotal;

	}
    

    this.calcTax=function(){
    	this.tax=mealCost*(6/100);
    	return this.tax;

    }

    this.calcTip=fucntion(){
    	var subTotal=calcSubTotal();
    	this.tip=subTotal*(20/100);

    	return this.tip;

    }

    this.calcSubTotal=function(){
    	var tax=calcTax();
        this.subTotal=tax+mealCost;

         return this.subTotal;
    }

    <!DOCTYPE html>
<html>
<head>
<title>Bill</title>
</head>
<style>
<body>
<!DOCTYPE html>
<html>
	<head>
		<title>Assign Server</title>
    </head>
    
    <style>
    body{
        background: whitesmoke;
        
    }
    h1{
        text-align: center;
		color: black;
        font-size: 50;
		font: 36px Impact;
		margin-top: 5px;
    	margin-bottom: 5px;
    	padding-left: 5px;
        
        
    }
    form{
        
		text-align: center;
		background-color: rgb(238, 238, 238);
		
    }
	ul li{
		background-color: rgb(238, 238, 238);
	}
	
	label{
		font: 28px Verdana, sans-serif;
	}
    
	
	}
	button{
		background-color: dodgerblue;
    	color: white;
    	text-align: center;
    	
		font: 24px Impact;
	}
        
</style>
<form id = "">
           
			<h1> Get The Bill </h1>
              <br>
              <b>
             <br>
            <label for="Food Cost">Food cost:</label>
			<input id = "hostInput" placeholder ="Enter the price">
			<br>
			<br>
			<br>
			<br>
			
			
			<label for="Drink Cost">Drink Cost:</label>
			<input type = "number" input id = "DrinkPriceInput" placeholder = "Enter the price">
			<br>
			<br>
			<br>
			<br>

}