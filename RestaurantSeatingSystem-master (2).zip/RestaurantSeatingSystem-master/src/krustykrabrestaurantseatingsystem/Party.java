/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package krustykrabrestaurantseatingsystem;

/**
 *
 * @author charleslyding
 */
public class Party {
    
   private int numberOfGuests; //Guests attending Restaurant
   private int numberOfAdults; //Adults attending Restuarant
   private int numberOfChildren; //Children attending Restaurant
   
   public void addGuests(int numberOfGuests){
       numberOfGuests = this.numberOfGuests;
   }
   
   public int countAdultsAndChildren(){
       return -1;
   }
   
   
   
   
   
   
    
}
