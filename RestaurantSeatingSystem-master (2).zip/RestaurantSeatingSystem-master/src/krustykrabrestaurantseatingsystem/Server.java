/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package krustykrabrestaurantseatingsystem;

/**
 *
 * @author charleslyding
 */
public class Server extends Employee{
    
    private String assignedSection;
    private int totalTips;
    
    public void chargeParty(){
        
    }
    
}
